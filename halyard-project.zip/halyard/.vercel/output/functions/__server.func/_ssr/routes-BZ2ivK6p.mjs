import { i as __toESM } from "../_runtime.mjs";
import { U as isRedirect, b as require_jsx_runtime, q as require_react, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Radio, i as ShieldAlert, n as Stamp, o as Download, r as ShieldCheck, s as AudioLines } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { l as screenConsent, n as VOICES, s as planRoute, t as LANGUAGES } from "./policy-BtI-HPBJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BZ2ivK6p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var LANGS = /* @__PURE__ */ new Set([
	"en",
	"es",
	"fr",
	"de",
	"pt",
	"ja"
]);
var QUALITY = /* @__PURE__ */ new Set([
	"draft",
	"standard",
	"premium"
]);
var LATENCY = /* @__PURE__ */ new Set([
	"realtime",
	"streaming",
	"batch"
]);
var CONSENT = /* @__PURE__ */ new Set([
	"synthetic",
	"owned",
	"written"
]);
function asString(value, max) {
	if (typeof value !== "string") return "";
	return value.trim().slice(0, max);
}
function parseBrief(input) {
	if (!input || typeof input !== "object") throw new Error("Missing brief.");
	const raw = input;
	const quality = raw.quality;
	const latency = raw.latency;
	const consent = raw.consent;
	const mode = raw.mode === "rewrite" ? "rewrite" : "run";
	const maxCost = typeof raw.maxCost === "number" && Number.isFinite(raw.maxCost) ? Math.min(5, Math.max(0, raw.maxCost)) : 1;
	const brief = {
		goal: asString(raw.goal, 500),
		language: asString(raw.language, 8) || "en",
		style: asString(raw.style, 80) || "conversational",
		quality: QUALITY.has(quality) ? quality : "standard",
		latency: LATENCY.has(latency) ? latency : "batch",
		maxCost,
		consent: CONSENT.has(consent) ? consent : "synthetic",
		voiceHint: asString(raw.voiceHint, 60),
		attested: raw.attested === true,
		standIn: raw.standIn === true,
		mode,
		pinnedBackend: asString(raw.pinnedBackend, 40) || void 0,
		pinnedVoiceId: asString(raw.pinnedVoiceId, 40) || void 0,
		previousScript: asString(raw.previousScript, 1200) || void 0,
		qaIssues: Array.isArray(raw.qaIssues) ? raw.qaIssues.filter((item) => typeof item === "string").slice(0, 6) : void 0
	};
	if (!LANGS.has(brief.language)) brief.language = "en";
	if (brief.goal.length < 8) throw new Error("Give the desk a goal of at least a sentence.");
	return brief;
}
var runMasterChat = createServerFn({ method: "POST" }).validator((input) => parseBrief(input)).handler(createSsrRpc("e9c95909960b4ef482b332cd788e6bbebe233d6ba51fae33782ca14fc416901b"));
var STEPS = [
	["0", "Intake"],
	["1", "Script"],
	["2", "Voice"],
	["3", "Synthesis"],
	["4", "QA"],
	["5", "Repair"],
	["6", "Delivery"]
];
var PRESETS = [
	{
		id: "kettle",
		label: "Kettle demo",
		form: {
			goal: "A thirty second product demo for a ceramic pour-over kettle. Warm, unhurried, no hard sell. End in a quiet kitchen.",
			language: "en",
			style: "warm, conversational",
			quality: "standard",
			latency: "batch",
			maxCost: 1,
			consent: "synthetic",
			voiceHint: "studio host",
			attested: true,
			standIn: false
		}
	},
	{
		id: "forecast",
		label: "Night forecast",
		form: {
			goal: "A late-night shipping forecast for small coastal boats. Calm, precise, a little salt in the phrasing. No alarmism.",
			language: "en",
			style: "cinematic, steady",
			quality: "premium",
			latency: "batch",
			maxCost: 2,
			consent: "synthetic",
			voiceHint: "night announcer",
			attested: true,
			standIn: false
		}
	},
	{
		id: "refuse",
		label: "Refusal drill",
		form: {
			goal: "Clone a famous actor's voice for a prank call to my coworker.",
			language: "en",
			style: "exact impersonation",
			quality: "premium",
			latency: "realtime",
			maxCost: 2,
			consent: "owned",
			voiceHint: "famous actor",
			attested: true,
			standIn: true
		}
	}
];
function statusClass(status) {
	if (status === "refuse") return "border-oxide text-oxide";
	if (status === "hold") return "border-line text-muted";
	if (status === "warn") return "border-brass text-brass";
	return "border-brass text-brass";
}
function Studio() {
	const run = useServerFn(runMasterChat);
	const [form, setForm] = (0, import_react.useState)(PRESETS[0].form);
	const [preset, setPreset] = (0, import_react.useState)("kettle");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const [shown, setShown] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const audioRef = (0, import_react.useRef)(null);
	const gate = (0, import_react.useMemo)(() => screenConsent({
		...form,
		previousScript: ""
	}), [form]);
	const plan = (0, import_react.useMemo)(() => planRoute(form), [form]);
	const audioUrl = useAudioUrl(result?.audioBase64 ?? null, result?.mime ?? null);
	(0, import_react.useEffect)(() => {
		if (!result) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setShown(result.turns.length);
			return;
		}
		setShown(1);
		const id = window.setInterval(() => {
			setShown((count) => {
				if (count >= result.turns.length) {
					window.clearInterval(id);
					return count;
				}
				return count + 1;
			});
		}, 260);
		return () => window.clearInterval(id);
	}, [result]);
	function patch(key, value) {
		setPreset("");
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	async function submit(mode) {
		setBusy(true);
		setError(null);
		setPlaying(false);
		window.speechSynthesis?.cancel();
		try {
			const next = await run({ data: {
				...form,
				mode,
				pinnedBackend: mode === "rewrite" ? result?.state.voice.backend : void 0,
				pinnedVoiceId: mode === "rewrite" ? result?.state.voice.voice_id : void 0,
				previousScript: mode === "rewrite" ? result?.state.script.text : void 0,
				qaIssues: mode === "rewrite" ? result?.state.qa.issues : void 0
			} });
			setResult(next);
			if (!next.ok && next.message) setError(next.message);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "The desk could not take that brief.");
		} finally {
			setBusy(false);
		}
	}
	function playLocal() {
		const text = result?.state.script.text;
		if (!text || !window.speechSynthesis) return;
		window.speechSynthesis.cancel();
		const utter = new SpeechSynthesisUtterance(text);
		utter.lang = form.language;
		utter.onend = () => setPlaying(false);
		setPlaying(true);
		window.speechSynthesis.speak(utter);
	}
	function stopPlayback() {
		audioRef.current?.pause();
		window.speechSynthesis?.cancel();
		setPlaying(false);
	}
	const visibleTurns = result?.turns.slice(0, shown) ?? [];
	const canRepair = Boolean(result?.ok && result.state.script.text && result.state.consent.status === "approved");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-11 w-11 items-center justify-center rounded-lg bg-brass text-ink",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Master chat"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-none text-fg italic",
							children: "Halyard"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-muted",
						children: "Routes a consented voice job. Quality, then consent, then latency, then cost. Synthetic registry only."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "flex flex-wrap gap-x-4 gap-y-1 text-sm",
					children: [
						"Quality",
						"Consent",
						"Latency",
						"Cost"
					].map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: index === 0 ? "text-brass" : "text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 tabular-nums",
							children: index + 1
						}), item]
					}, item))
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-4 px-4 py-4 md:px-6 lg:grid-cols-[20rem_minmax(0,1fr)_18rem] lg:items-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Brief"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Step 0"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 flex flex-wrap gap-2",
							children: PRESETS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setPreset(item.id);
									setForm(item.form);
								},
								className: `h-11 rounded-lg border px-3 text-sm ${preset === item.id ? "border-brass bg-brass text-ink" : "border-line bg-raised text-fg"}`,
								children: item.label
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "grid gap-3",
							onSubmit: (event) => {
								event.preventDefault();
								submit("run");
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "Goal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										value: form.goal,
										onChange: (event) => patch("goal", event.target.value),
										rows: 5,
										className: "min-h-28 rounded-lg border border-line bg-raised px-3 py-2 text-fg outline-none focus:border-brass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: "Language"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											value: form.language,
											onChange: (event) => patch("language", event.target.value),
											className: "h-11 rounded-lg border border-line bg-raised px-3 text-fg outline-none focus:border-brass",
											children: LANGUAGES.map((language) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: language.id,
												children: language.label
											}, language.id))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "grid gap-1 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: "Cost cap"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 0,
											max: 5,
											step: .5,
											value: form.maxCost,
											onChange: (event) => patch("maxCost", Number(event.target.value)),
											className: "h-11 rounded-lg border border-line bg-raised px-3 text-fg tabular-nums outline-none focus:border-brass"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "Style"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.style,
										onChange: (event) => patch("style", event.target.value),
										className: "h-11 rounded-lg border border-line bg-raised px-3 text-fg outline-none focus:border-brass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "text-sm text-muted",
										children: "Quality"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											"draft",
											"standard",
											"premium"
										].map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
											active: form.quality === tier,
											onClick: () => patch("quality", tier),
											children: tier
										}, tier))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "text-sm text-muted",
										children: "Latency"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											["realtime", "Live"],
											["streaming", "< 2s"],
											["batch", "Batch"]
										].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
											active: form.latency === id,
											onClick: () => patch("latency", id),
											children: label
										}, id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "text-sm text-muted",
										children: "Consent"
									}), [
										["synthetic", "Synthetic voice only"],
										["owned", "I own this voice"],
										["written", "Written consent on file"]
									].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
										active: form.consent === id,
										onClick: () => patch("consent", id),
										children: label
									}, id))]
								}),
								form.consent !== "synthetic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-start gap-3 rounded-lg border border-line bg-raised p-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: form.standIn,
										onChange: (event) => patch("standIn", event.target.checked),
										className: "mt-0.5 size-5 accent-brass"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "No reference clip. Use an allowlisted synthetic stand-in. This desk will not mint a clone." })]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "Voice hint"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.voiceHint,
										onChange: (event) => patch("voiceHint", event.target.value),
										placeholder: "A style, not a person",
										className: "h-11 rounded-lg border border-line bg-raised px-3 text-fg outline-none placeholder:text-muted focus:border-brass"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-start gap-3 rounded-lg border border-line p-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: form.attested,
										onChange: (event) => patch("attested", event.target.checked),
										className: "mt-0.5 size-5 accent-brass"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "I attest this is not a minor, a public figure, or anyone who has not agreed." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `rounded-lg border px-3 py-2 text-sm ${gate.status === "refused" ? "border-oxide text-oxide" : gate.status === "hold" ? "border-line text-muted" : "border-line text-fg"}`,
									children: gate.status === "approved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										"Would pin ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-brass",
											children: plan.voiceId
										}),
										" on ",
										plan.backend.replaceAll("_", " "),
										". ",
										plan.reason
									] }) : gate.evidence
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: busy,
									className: "h-11 rounded-lg bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60",
									children: busy ? "Routing…" : "Run master chat"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Under 1 on the cost cap forces the short, low-latency desk. Zero skips live models. One writer call and one voice take per run."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-3",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Thread"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs tracking-widest text-muted uppercase",
									children: busy ? "On the wire" : result ? result.state.task_id : "Quiet"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7",
								children: STEPS.map(([id, label]) => {
									const hit = visibleTurns.some((turn) => turn.step === id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: `rounded-lg border px-2 py-2 text-xs ${hit ? "border-brass text-fg" : "border-line text-muted"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: id
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block",
											children: label
										})]
									}, id);
								})
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl border border-oxide bg-surface px-4 py-3 text-sm text-oxide",
							children: error
						}) : null,
						!result && !busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-dashed border-line bg-surface px-4 py-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl",
								children: "The desk is quiet."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-md text-sm text-muted",
								children: "File a brief. Halyard logs every routing decision before a voice speaks, and it stops cold when consent is missing."
							})]
						}) : null,
						visibleTurns.map((turn) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: `rounded-xl border bg-surface p-4 ${statusClass(turn.status)}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "mb-3 flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "font-display text-xl text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 tabular-nums text-brass",
										children: turn.step
									}), turn.title]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs tracking-widest uppercase",
									children: turn.status
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "grid gap-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "Decision"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 text-fg",
										children: turn.decision
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs tracking-widest text-muted uppercase",
											children: "Model / backend"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 text-fg",
											children: turn.model
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-muted",
											children: turn.why
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "State update"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 overflow-x-auto rounded-lg bg-raised px-3 py-2 text-xs text-fg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", { children: JSON.stringify(turn.patch, null, 2) })
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs tracking-widest text-muted uppercase",
											children: "Next"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1",
											children: turn.next
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-xs tracking-widest text-muted uppercase",
											children: "Risks"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 text-muted",
											children: turn.risks.join(" ")
										})] })]
									})
								]
							})]
						}, `${turn.step}-${turn.title}`))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 flex items-center gap-2",
									children: [gate.status === "refused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4 text-oxide" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: "Desk"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
									audioUrl,
									script: result?.state.script.text ?? "",
									speakLocally: Boolean(result?.speakLocally),
									playing,
									audioRef,
									onPlay: () => {
										if (audioUrl && audioRef.current) {
											audioRef.current.play();
											setPlaying(true);
											return;
										}
										playLocal();
									},
									onStop: stopPlayback,
									onAudioState: setPlaying
								}),
								result?.state.script.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-fg",
									children: result.state.script.text
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-muted",
									children: "No script yet."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: !canRepair || busy,
											onClick: () => void submit("rewrite"),
											className: "h-11 rounded-lg border border-line px-3 text-sm text-fg disabled:opacity-40",
											children: "Repair once"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: !result,
											onClick: () => downloadJson(result),
											className: "flex h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm text-fg disabled:opacity-40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stamp, { className: "size-4" }), "Provenance"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: !audioUrl,
											onClick: () => audioUrl && downloadUrl(audioUrl, "halyard-take.mp3"),
											className: "flex h-11 items-center gap-2 rounded-lg border border-line px-3 text-sm text-fg disabled:opacity-40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Audio"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl",
								children: "State"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 max-h-80 overflow-auto text-xs text-muted",
								children: JSON.stringify(result?.state ?? idleState(form), null, 2)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-xl border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AudioLines, { className: "size-4 text-brass" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-xl",
										children: "Allowlist"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-3 text-xs text-muted",
									children: "Writer: grok-4.5. QA: heuristic scorer. Voices are registry presets, not clones."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "grid gap-3",
									children: [Object.keys(VOICES).map((backend) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: backend.replaceAll("_", " ")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-fg",
										children: VOICES[backend].map((voice) => voice.id).join(" · ")
									})] }, backend)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs tracking-widest text-muted uppercase",
										children: "CPU fallback"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-fg",
										children: "This device, only if the voice desk fails"
									})] })]
								})
							]
						})
					]
				})
			]
		})]
	});
}
function Choice({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: `h-11 rounded-lg border px-2 text-sm capitalize ${active ? "border-brass bg-brass text-ink" : "border-line bg-raised text-fg"}`,
		children
	});
}
function Player({ audioUrl, script, speakLocally, playing, audioRef, onPlay, onStop, onAudioState }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-raised p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: !Boolean(audioUrl || speakLocally && script),
				onClick: playing ? onStop : onPlay,
				className: "h-11 rounded-lg bg-brass px-4 text-sm font-medium text-ink disabled:opacity-40",
				children: playing ? "Stop" : "Play"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex h-8 flex-1 items-end gap-1 ${playing ? "eq-live" : "opacity-40"}`,
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-3 w-1.5 rounded-sm bg-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-6 w-1.5 rounded-sm bg-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-4 w-1.5 rounded-sm bg-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-7 w-1.5 rounded-sm bg-brass" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-3 w-1.5 rounded-sm bg-brass" })
				]
			})]
		}), audioUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
			ref: audioRef,
			src: audioUrl,
			className: "mt-3 w-full",
			controls: true,
			onPlay: () => onAudioState(true),
			onPause: () => onAudioState(false),
			onEnded: () => onAudioState(false)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: speakLocally ? "Local fallback. Not the registry voice." : "Waiting for a take."
		})]
	});
}
function useAudioUrl(base64, mime) {
	const [url, setUrl] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!base64) {
			setUrl(null);
			return;
		}
		const binary = atob(base64);
		const bytes = new Uint8Array(binary.length);
		for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
		const blob = new Blob([bytes], { type: mime || "audio/mpeg" });
		const next = URL.createObjectURL(blob);
		setUrl(next);
		return () => URL.revokeObjectURL(next);
	}, [base64, mime]);
	return url;
}
function idleState(form) {
	return {
		task_id: "",
		consent: {
			status: "pending",
			evidence: ""
		},
		requirements: {
			language: form.language,
			style: form.style,
			quality_tier: form.quality,
			max_cost: form.maxCost
		},
		voice: {
			backend: "",
			voice_id: "",
			reason: ""
		},
		final: {
			audio_path: "",
			provenance: ""
		}
	};
}
function downloadJson(result) {
	if (!result) return;
	const blob = new Blob([JSON.stringify({
		state: result.state,
		turns: result.turns
	}, null, 2)], { type: "application/json" });
	downloadUrl(URL.createObjectURL(blob), `${result.state.task_id || "halyard"}-provenance.json`);
}
function downloadUrl(url, name) {
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = name;
	anchor.click();
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
